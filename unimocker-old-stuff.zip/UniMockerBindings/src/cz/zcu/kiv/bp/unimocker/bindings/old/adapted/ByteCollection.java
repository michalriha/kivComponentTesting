package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Byte numbers
 * @author Michal
 */
public class ByteCollection extends MyCollection<Byte>
{
	private static final long serialVersionUID = -2994576284398065298L;
}
