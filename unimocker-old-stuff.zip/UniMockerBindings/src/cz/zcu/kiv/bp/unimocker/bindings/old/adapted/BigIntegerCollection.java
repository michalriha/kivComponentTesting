package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

import java.math.BigInteger;

/**
 * MyCollection for BigInteger numbers
 * @author Michal
 */
public class BigIntegerCollection extends MyCollection<BigInteger>
{
	private static final long serialVersionUID = -8936724067703455601L;
}
