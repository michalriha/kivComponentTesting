package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Integer numbers
 * @author Michal
 */
public class IntegerCollection extends MyCollection<Integer>
{
	private static final long serialVersionUID = 8307838773725057281L;
}
