package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Long numbers
 * @author Michal
 */
public class LongCollection extends MyCollection<Long>
{
	private static final long serialVersionUID = 4542051917154593629L;
}
