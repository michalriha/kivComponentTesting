package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

import java.math.BigDecimal;

/**
 * MyCollection for BigDecimal numbers
 * @author Michal
 */
public class BigDecimalCollection extends MyCollection<BigDecimal>
{
	private static final long serialVersionUID = -764355562059209332L;
}
