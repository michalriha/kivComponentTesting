package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Strings
 * @author Michal
 */
public class StringCollection extends MyCollection<String>
{
	private static final long serialVersionUID = -9083327057165641724L;
}
