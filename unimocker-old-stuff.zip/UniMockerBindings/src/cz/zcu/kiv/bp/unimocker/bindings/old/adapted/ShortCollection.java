package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Short numbers
 * @author Michal
 */
public class ShortCollection extends MyCollection<Short>
{
	private static final long serialVersionUID = -4430340326766549436L;
}
