package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Boolean values
 * @author Michal
 */
public class BooleanCollection extends MyCollection<Boolean>
{
	private static final long serialVersionUID = -2944969404401831285L;
}
