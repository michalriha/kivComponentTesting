package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Float numbers
 * @author Michal
 */
public class FloatCollection extends MyCollection<Float>
{
	private static final long serialVersionUID = 2618856988537836188L;
}
