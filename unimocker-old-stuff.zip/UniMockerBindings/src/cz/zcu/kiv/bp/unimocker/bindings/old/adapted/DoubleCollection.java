package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

/**
 * MyCollection for Double numbers
 * @author Michal
 */
public class DoubleCollection extends MyCollection<Double>
{
	private static final long serialVersionUID = -923060142701526588L;
}
