package cz.zcu.kiv.bp.unimocker.bindings.old.adapted;

import java.io.File;

/**
 * MyCollection for File objects
 * @author Michal
 */
public class FileCollection extends MyCollection<File>
{
	private static final long serialVersionUID = -7793750121287919309L;
}
